pref("extensions.zoteroTeam14.version", "");

pref("extensions.zoteroTeam14.installed", false);

pref("extensions.zoteroTeam14.skipInstallation", false);